﻿angular.module('sampleApp')
    .factory('sampleService', SampleService);
SampleService.$inject = [];
function SampleService() {
    return {
        getAccomodations: getAccomodations,
        getHomeAccomodations: getHomeAccomodations
    };

    // Retrieves materials for a selected Accomodation
    function getAccomodations(key) {
            switch (key) {
                case "Dining":
                    return ['Timber window', 'Metal frame'];
                case "Kitchen":
                    return ['PVC/Timber window', 'Metal frame'];
            }
    }

    // Retrieves all Accomodations
    function getHomeAccomodations() {
        return [
            { name: 'Dining', selected: false, title: 'Dining' },
            { name: 'Kitchen', selected: false, title: 'Kitchen' }
        ];
    }
}