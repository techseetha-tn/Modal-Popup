﻿angular.module('sampleApp')
    .controller('materialsController', MaterialsController);
MaterialsController.$inject = ['$scope','sampleService', '$sce'];
var materialsController;
function MaterialsController($scope, sampleService, $sce) {
    materialsController = this;

    // Object that holds each accomodation and selected materials, used for displaying in UI in a specific format
    materialsController.selectedData = [];

    // Array that captures categories selected by user from materials directive. For ex: materials selected under each Accomodation
    materialsController.SelectedDetails = [{
        key: '',
        values: []
    }];

    // Fetch items that would be displayed as Buttons
    materialsController.HomeAccomodations = sampleService.getHomeAccomodations();

    // Method that displays user selections in a specified format
    materialsController.DisplayDetails = DisplayDetails;

    function DisplayDetails(selectedDetails) {
        if (!!selectedDetails) materialsController.selectedData = [];
        _.each(selectedDetails, function (value, index) {
            if (!!value.key)
                materialsController.selectedData.push("Accomodation: " + value.key + " / Material(s): " + value.values);
        });       

        // Reset selections once popup is closed
        materialsController.SelectedDetails = [];
    }
}