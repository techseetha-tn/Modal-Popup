﻿angular.module('sampleApp')
    .controller('sampleController', SampleController);
SampleController.$inject = ['$scope'];
var SampleObject;
function SampleController($scope) {
    SampleObject = this;
    SampleObject.AccomodationModel = {
        Title: "Reusable directive for various accomodations"
    };
    SampleObject.homeAccomodations = [
        { name: 'Dining', selected: false, title: 'Dining' },
        { name: 'MasterBedroom', selected: false, title: 'Master Bedroom' },
        { name: 'Living', selected: false, title: 'Living' },
        { name: 'Kitchen', selected: false, title: 'Kitchen' },
        { name: 'Yard', selected: false, title: 'Yard' },
        { name: 'Bedroom1', selected: false, title: 'Bedroom1' },
        { name: 'Bedroom2', selected: false, title: 'Bedroom2' },
        { name: 'Bedroom3', selected: false, title: 'Bedroom3' }
    ];

    SampleObject.hotelAccomodations = [
        { name: 'Dining', selected: false, title: 'Dining' },
        { name: 'Living', selected: false, title: 'Living' },
        { name: 'Kitchen', selected: false, title: 'Kitchen' },
        { name: 'Yard', selected: false, title: 'Yard' },
        { name: 'Bedroom1', selected: false, title: 'Bedroom1' },
        { name: 'Bedroom2', selected: false, title: 'Bedroom2' },
        { name: 'Bedroom3', selected: false, title: 'Bedroom3' }
    ];
}