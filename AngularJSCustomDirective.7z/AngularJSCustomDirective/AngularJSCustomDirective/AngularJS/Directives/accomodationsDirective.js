﻿angular.module('sampleApp')
    .directive('accomodations', accomodations);
accomodations.$inject = [];

function accomodations() {
    var directive = {
        restrict: 'E',
        replace: true,
        templateUrl: 'AngularJS/Views/accomodations.html',
        scope: {
            title: '@',
            accomodations: '=',
        },
        link: linkFn
    };

    return directive;

    function linkFn(scope) {
        scope.selectedOptions = [];
        scope.item = '';
        scope.displaySelectedOptions = displaySelectedOptions;

        // Used as a Callback from the displayList Directive
        function displaySelectedOptions(item) {
            // Add selected Accomodations to an array which will be displayed in UI using ngRepeat
            if (!!item)
                scope.selectedOptions.push(item);
        }
    }

    /*
    Notes: 
    When replace: true is set and template property is used, the interpolation and directive processing does not work
    A scope variable item is declared that will be passed to the common directive. The common directive retrieves selected accomodation back
    */
}