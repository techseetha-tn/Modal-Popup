﻿angular.module('sampleApp')
    .directive('displayList', displayList);
displayList.$inject = ['$timeout'];
function displayList($timeout) {
    var directive = {
        restrict: 'E',
        replace: true,
        templateUrl: 'AngularJS/Views/displayList.html',
        scope: {
            accomodations: '=',
            item: '=',
            displaySelectedOptions: '&'
        },
        link: linkFunction
    };

    return directive;

    function linkFunction(scope, element, attr) {
        scope.displayOptions = displayOptions;

        function displayOptions(selectedItem, obj) {
            // Selected Accomodation is passed to the Callback defined in accomodations Directive
            scope.item = selectedItem;
            obj.target.disabled = true;
            $timeout(function () {
                if (scope.displaySelectedOptions()) {
                    scope.displaySelectedOptions()(scope.item);
                }                    
            });
        }
    }
}