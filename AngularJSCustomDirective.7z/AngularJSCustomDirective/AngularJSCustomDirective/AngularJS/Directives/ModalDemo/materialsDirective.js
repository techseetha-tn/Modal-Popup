﻿angular.module('sampleApp')
    .directive('materials', Materials);
Materials.$inject = ['$timeout','sampleService'];
function Materials($timeout, sampleService) {
    var directive = {
        restrict: 'E',
        templateUrl: 'AngularJS/Views/ModalDemo/materials.html',
        scope: {
            homeAccomodations: '=',
            selectedDetails:'=',
            displayDetails:'&'
        },
        link: linkFunction
    };
    return directive;

    function linkFunction(scope, element, attr) {
        scope.selectedKey = '';
        scope.materials = [];
        scope.selectedMaterials = [];
        scope.showDetails = showDetails;
        scope.addMaterials = addMaterials;
        scope.sendDetails = sendDetails;

        function showDetails(key, obj) {
            scope.selectedKey = key;

            // Disabling the button once selected
            obj.target.disabled = true;

            $("#materialsSection input[type='button']").attr("disabled", false);

            // Display related materials when an Accomodation is selected
            scope.materials = sampleService.getAccomodations(key);
        }

        function addMaterials(material, obj) {
            // Disabling the Material once selected
            obj.target.disabled = true;

            // Add selected materials for the selected Accomodation to an array
            var selectedIndex = _.findIndex(scope.selectedDetails, function (value) {
                return value.key === scope.selectedKey
            });

            if (selectedIndex > -1) {
                scope.selectedDetails[selectedIndex].values.push(material);
            }
            else {
                scope.selectedDetails.push({ key: scope.selectedKey, values: [material] });
            }
        }

        function sendDetails() {
            // Pass selected Accomodations and materials to Callback function (right now defined in material Controller)
            scope.selectedKey = '';
            scope.materials = [];
            scope.selectedMaterials = [];
            $("input[type='button']").attr("disabled", false);
            $timeout(function () {
                if (scope.displayDetails()) {
                    scope.displayDetails()(scope.selectedDetails);
                }
            });
        }
    }
}